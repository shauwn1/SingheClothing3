// HomeViewModel.swift
import Foundation

class HomeViewModel: ObservableObject {
    @Published var categories: [String] = []
    @Published var clothingItems: [ClothingItem] = []
    @Published var selectedCategory: String? {
        didSet {
            loadProductsForCategory()
        }
    }
    
    private let apiService = ApiService()
    var cart: Cart
       
    init(cart: Cart) {
        self.cart = cart
        loadCategories()
    }
    
    func loadCategories() {
        apiService.fetchCategories { [weak self] categories in
            self?.categories = categories ?? []
        }
    }
    
    func loadProductsForCategory() {
        guard let category = selectedCategory else { return }
        apiService.fetchProducts(forCategory: category) { [weak self] products in
            self?.clothingItems = products ?? []
        }
    }
    
    func addProductToCart(product: ClothingItem, size: String) {
        cart.addToCart(product: product, size: size)
    }
}
