// ProductDetailView.swift

import SwiftUI

struct ProductDetailView: View {
    @ObservedObject var cart: Cart
    let product: ClothingItem
    @State private var selectedSize: String = "Medium" // Default size

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                AsyncImage(url: URL(string: product.image)) { image in
                    image.resizable()
                } placeholder: {
                    Color.gray
                }
                .frame(width: 300, height: 300)
                .cornerRadius(12)

                Text(product.title)
                    .font(.title2)
                Text(product.description)
                Text("Price: $\(product.price, specifier: "%.2f")")
                    .font(.headline)

                // Size Picker
                Text("Select Size:")
                Picker("Select Size:", selection: $selectedSize) {
                    ForEach(["Small", "Medium", "Large", "XL", "XXL"], id: \.self) { size in
                        Text(size).tag(size)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())

                Spacer()

                // Add to Cart Button
                Button(action: {
                    // Add to cart with selected size
                    cart.addToCart(product: product, size: selectedSize)
                }) {
                    Text("Add to Cart")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 200, height: 50)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
            .padding()
        }
        .navigationTitle("Product Details")
        .navigationBarTitleDisplayMode(.inline)
    }
}
