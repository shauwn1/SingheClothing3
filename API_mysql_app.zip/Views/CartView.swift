//
//  CartView.swift
//  SingheClothing
//
//  Created by Shehara Jayasooriya on 2024-03-25.
//

import SwiftUI

struct CartView: View {
    @ObservedObject var cart: Cart

    var body: some View {
        List {
            ForEach(cart.items) { cartItem in
                HStack {
                    AsyncImage(url: URL(string: cartItem.product.image)) { image in
                        image.resizable()
                    } placeholder: {
                        Color.gray
                    }
                    .frame(width: 50, height: 50)

                    VStack(alignment: .leading) {
                        Text(cartItem.product.title)
                        Text("\(cartItem.quantity) x $\(cartItem.product.price, specifier: "%.2f")")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                
            }.onDelete(perform: deleteItems)
        }
        .navigationTitle("Cart")
    }
    // Method to delete items
        private func deleteItems(at offsets: IndexSet) {
            for index in offsets {
                let itemID = cart.items[index].id
                cart.removeFromCart(itemID: itemID)
            }
        }
}



