// HomeView.swift
import SwiftUI

struct HomeView: View {
    @StateObject var viewModel: HomeViewModel

    init(cart: Cart) {
        _viewModel = StateObject(wrappedValue: HomeViewModel(cart: cart))
    }

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Categories")) {
                    ForEach(viewModel.categories, id: \.self) { category in
                        Button(action: {
                            viewModel.selectedCategory = category
                        }) {
                            Text(category)
                        }
                    }
                }

                Section(header: Text("Products")) {
                    ForEach(viewModel.clothingItems) { item in
                        NavigationLink(destination: ProductDetailView(cart: viewModel.cart, product: item)) {
                            HStack {
                                AsyncImage(url: URL(string: item.image)) { phase in
                                    if let image = phase.image {
                                        image.resizable()
                                    } else if phase.error != nil {
                                        Color.red
                                    } else {
                                        Color.blue
                                    }
                                }
                                .frame(width: 100, height: 100)
                                .cornerRadius(10)
                                Text(item.title)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Clothing Store")
            .navigationBarItems(trailing: CartButtonView(cart: viewModel.cart))
            .onAppear {
                viewModel.loadCategories()
            }
        }
    }
}
