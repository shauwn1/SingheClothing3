//
//  APIServiceModel.swift
//  SingheClothing
//
//  Created by Shehara Jayasooriya on 2024-03-24.
//

import Foundation
class ApiService {
    private let baseURL = "http://localhost:3000/api"

    func fetchProducts(forCategory category: String, completion: @escaping ([ClothingItem]?) -> Void) {
        let formattedCategory = category.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        guard let url = URL(string: "\(baseURL)/products/\(formattedCategory)") else {
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching products: \(error)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("No data received")
                completion(nil)
                return
            }
            
            if let products = try? JSONDecoder().decode([ClothingItem].self, from: data) {
                DispatchQueue.main.async {
                    completion(products)
                }
            } else {
                print("Failed to decode products")
                completion(nil)
            }
        }.resume()
    }

    func fetchCategories(completion: @escaping ([String]?) -> Void) {
        // Assuming you have an endpoint in your API to fetch categories
        guard let url = URL(string: "\(baseURL)/categories") else {
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                completion(nil)
                return
            }
            
            let categories = try? JSONDecoder().decode([String].self, from: data)
            DispatchQueue.main.async {
                completion(categories)
            }
        }.resume()
    }
}
