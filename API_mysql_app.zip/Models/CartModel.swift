// CartModel.swift
import Foundation

struct CartItem: Identifiable {
    var id: Int
    var product: ClothingItem
    var size: String
    var quantity: Int
}

class Cart: ObservableObject {
    @Published var items: [CartItem] = []

    func addToCart(product: ClothingItem, size: String) {
        if let index = items.firstIndex(where: { $0.product.id == product.id && $0.size == size }) {
            items[index].quantity += 1
        } else {
            let newItem = CartItem(id: items.count + 1, product: product, size: size, quantity: 1)
            items.append(newItem)
        }
    }
    
    
    func removeFromCart(itemID: Int) {
            items.removeAll { $0.id == itemID }
        }
    
    
    var totalItems: Int {
           items.reduce(0) { $0 + $1.quantity }
       }
}
