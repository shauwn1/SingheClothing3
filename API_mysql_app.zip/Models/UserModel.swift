import Foundation

struct User: Codable {
    var email: String
    var password: String
}
